
import java.awt.Component;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DSL {

	private WebDriver driver;
	String DSLnavegador = "";

	public DSL(WebDriver driver) {
		this.driver = driver;
	}

	public void clicarObjetoId(String id) {
		driver.findElement(By.id(id)).click();
	}

	public void clicarObjetoXpath(String xpath) {
		driver.findElement(By.xpath(xpath)).click();
	}

	public void digitarNoTextbox(By id, String texto) {
		driver.findElement(id).clear();
		driver.findElement(id).sendKeys(texto);
	}

	public void digitarNoTextbox(String id_textbox, String texto) {
		digitarNoTextbox(By.id(id_textbox), texto);
	}

	public String obterTextoObjetoXpath(String xpath) {
		return driver.findElement(By.xpath(xpath)).getText();
	}

	public String obterTextoObjetoId(String id) {
		return driver.findElement(By.id(id)).getText();
	}

	public String escolheNavegador() {
		String Resposta;
		Component frame = null;
		ImageIcon icone = new ImageIcon(System.getProperty("user.dir") + "/src/main/resources/icon.png");
		Object[] navegadores = { "Firefox", "Chrome", "Safari" };

		String s = (String) JOptionPane.showInputDialog(frame, "Selecione um navegador:", "Seleção de Navegador",
				JOptionPane.PLAIN_MESSAGE, icone, navegadores, navegadores[0]);

		if (s == null) {
			Resposta = "Nenhum";
			return Resposta;
		} else {
			return s.toString();
		}

	}

}
