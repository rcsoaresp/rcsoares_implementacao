
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

public class PaginaHomeAmericanas {

	private WebDriver driver;
	private DSL dsl;
	
	String produto;
	String url = "https://americanas.com.br";
	String navegador = "";
		
	@Before
	public void inicializa() {
		dsl = new DSL(driver);
		navegador = dsl.escolheNavegador();
	}

	@After
	public void finaliza() {
		driver.quit();
	}

	@Test
	public void validaListaProdutoSucesso() throws InterruptedException {
		
		System.out.println("Execução em: " + navegador);

		switch (navegador.toString()) {
		case "Firefox":
			System.out.println("Execução no Firefox...");
			driver = new FirefoxDriver();
			driver.manage().window().setSize(new Dimension(1200, 765));
			driver.get(url);
			break;
		case "Chrome":
			System.out.println("Execução no Chrome...");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(url);
			break;
		case "Safari":
			System.out.println("Execução no Safari...");
			driver = new SafariDriver();
			driver.manage().window().setSize(new Dimension(1200, 765));
			driver.get(url);
			break;
		case "Nenhum":
			System.out.println("Você cancelou a execução !");
			System.exit(0);
		default:
			System.out.println("Erro na seleção !");
		}

		System.out.println("Executando teste em: " + navegador);

		produto = "iphone 11";
		dsl = new DSL(driver);

		buscaProdutoAmericanas(produto);

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		// Valida retorno da busca:

		System.out.println("Verificando se o produto procurado existe na loja...");

		// Tratamento para um possível fluxo alternativo de busca, quando uma cadeia de
		// caracteres especiais do tipo "!@#$%ˆ*()=" é o produto procurado:

		if (!driver
				.findElements(By
						.xpath("/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[6]/div/div/div/div[1]/svg"))
				.isEmpty()) {
			System.out.println("Você fez a busca por um Produto indisponível ou inválido!");
			System.out.println("RETORNO: " + driver.findElement(By.xpath(
					"/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[6]/div/div/div/div[2]/span[1]/span"))
					.getText());

			Assert.assertEquals("Ops! nenhum resultado encontrado para \"" + produto + "\".", driver.findElement(By
					.xpath("/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[6]/div/div/div/div[2]/span[1]/span"))
					.getText());
			return;
		}

		System.out.println("Produto achado!");
		System.out.println("Verificando correspondência do título com a busca...");

		// OBS: Dependendo da programação do site, o título pode vir com primeiras
		// letras em maiúsculas. Dessa forma, é aconselhável comparar textos em caixa
		// alta.

		String item = dsl.obterTextoObjetoXpath("//*[@id=\"content-middle\"]/div[1]/div/div/h1");
		Assert.assertEquals(produto.toUpperCase(), item.toUpperCase());
		System.out.println("Correspondência OK.");

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		// Escolha do primeiro produto na lista:
		System.out.println("Escolhendo o primeiro item da lista...");

		dsl.clicarObjetoXpath(
				"//*[@id=\"content-middle\"]/div[6]/div/div/div/div[1]/div[1]/div/div[2]/a/section/div[2]/div[1]/h2");

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		String descricaoDefaultProduto = dsl.obterTextoObjetoId("product-name-default");

		System.out.println("A descrição do produto clicado na lista foi: " + descricaoDefaultProduto);
		System.out.println("Escolha realizada com sucesso.");

		// System.out.println("Aguardando 5 segundos...");
		// Thread.sleep(5000);

		// Inclusão do produto ao carrinho de compras:
		// OBS: Se o item contiver detalhes de voltagem, cor ou característica
		// distintiva, uma janela popup abrirá
		// e será necessário aceitar uma opção. No teste em questão, utilizaremos a
		// opção padrão.
		// Mediante um mapeamento completo do quadro de características
		// distintivas, podemos acrescentar casos de testes para produtos com suas
		// respectivas características e validar a opção escolhida na lista do carrinho
		// para cada escolha, pois, nas regras de negócio, certamente existirá um caso
		// de uso que assegure a
		// escolha ditintiva do produto no carrinho do usuário (consumidor).
		System.out.println("Incluindo o primeiro produto no carrinho...");
		dsl.clicarObjetoId("btn-buy");
		System.out.println("Inclusão solicitada e aguardando se há características distintivas...");

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		// Aceitar a sugestão inicial:
		String aceitarXpath = "/html/body/div[6]/div/div/div[2]/div[3]/div/div[2]/div/a/div/span";

		if (!driver.findElements(By.xpath(aceitarXpath)).isEmpty()) {
			dsl.clicarObjetoXpath(aceitarXpath);
		} else {
			System.out.println("O produto procurado não possui característica distintiva para gerar popup de alerta.");
		}

		// Clicar no botão Continue, caso ele apareça quando uma garantia estendida for
		// aplicável:
		System.out.println("Buscando o botão \"Continue\" ...");
		String botaoContinueId = "btn-continue";

		if (!driver.findElements(By.id(botaoContinueId)).isEmpty()) {
			dsl.clicarObjetoId(botaoContinueId);
		} else {
			System.out.println("O produto procurado não apresenta o botão \"Continuar\".");
		}
		System.out.println("Inclusão realizada com sucesso.");

		// Validar produto selecionado dentro do carrinho:

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		String textoProdutoNoCarrinho = dsl.obterTextoObjetoXpath(
				"/html/body/div[4]/section/section/div[1]/div[2]/div[1]/section/ul/li/div[2]/div[1]/h2/a");

		System.out.println("A descrição do produto inserido no carrinho foi: " + textoProdutoNoCarrinho);

		Assert.assertEquals(textoProdutoNoCarrinho.toUpperCase(), descricaoDefaultProduto.toUpperCase());		
	}

	@Test
	// Fluxo Alternativo 1: produto inválido
	public void validaListaProdutoInvalido() throws InterruptedException {
				
		System.out.println("Execução em: " + navegador);

		switch (navegador.toString()) {
		case "Firefox":
			System.out.println("Execução no Firefox...");
			driver = new FirefoxDriver();
			driver.manage().window().setSize(new Dimension(1200, 765));
			driver.get(url);
			break;
		case "Chrome":
			System.out.println("Execução no Chrome...");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(url);
			break;
		case "Safari":
			System.out.println("Execução no Safari...");
			driver = new SafariDriver();
			driver.manage().window().setSize(new Dimension(1200, 765));
			driver.get(url);
			break;
		case "Nenhum":
			System.out.println("Você cancelou a execução !");
			System.exit(0);
		default:
			System.out.println("Erro na seleção !");
		}

		System.out.println("Executando teste em: " + navegador);

		produto = "!@#$%ˆ&";
		dsl = new DSL(driver);

		buscaProdutoAmericanas(produto);

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		System.out.println("Verificando se o produto é válido...");

		if (!driver
				.findElements(By
						.xpath("/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[6]/div/div/div/div[1]/svg"))
				.isEmpty()) {
			System.out.println("RETORNO: " + driver.findElement(By.xpath(
					"/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[6]/div/div/div/div[2]/span[1]/span"))
					.getText());

			Assert.assertEquals("Ops! nenhum resultado encontrado para \"" + produto + "\".", driver.findElement(By
					.xpath("/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[6]/div/div/div/div[2]/span[1]/span"))
					.getText());

			System.out.println("Você fez a busca por um produto INVÁLIDO e a página respondeu conforme esperado!");
			return;
		}

	}

	@Test
	// Fluxo Alternativo 2: produto indisponível
	public void validaListaProdutoIndisponivel() throws InterruptedException {

		System.out.println("Execução em: " + navegador);

		switch (navegador.toString()) {
		case "Firefox":
			System.out.println("Execução no Firefox...");
			driver = new FirefoxDriver();
			driver.manage().window().setSize(new Dimension(1200, 765));
			driver.get(url);
			break;
		case "Chrome":
			System.out.println("Execução no Chrome...");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(url);
			break;
		case "Safari":
			System.out.println("Execução no Safari...");
			driver = new SafariDriver();
			driver.manage().window().setSize(new Dimension(1200, 765));
			driver.get(url);
			break;
		case "Nenhum":
			System.out.println("Você cancelou a execução !");
			System.exit(0);
		default:
			System.out.println("Erro na seleção !");
		}

		System.out.println("Executando teste em: " + navegador);

		produto = "Mascara 3M PFF-2 com válvula";
		dsl = new DSL(driver);

		buscaProdutoAmericanas(produto);

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		// Valida retorno da busca:

		System.out.println("Verificando se o produto procurado é vendido na loja...");
		System.out.println("Produto achado!");
		System.out.println("Verificando correspondência do título com a busca...");

		String item = dsl.obterTextoObjetoXpath("//*[@id=\"content-middle\"]/div[1]/div/div/h1");

		Assert.assertEquals(produto.toUpperCase(), item.toUpperCase());
		System.out.println("Correspondência OK.");

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		// Escolha do primeiro produto na lista:
		System.out.println("Escolhendo o primeiro item da lista...");

		dsl.clicarObjetoXpath(
				"//*[@id=\"content-middle\"]/div[6]/div/div/div/div[1]/div[1]/div/div[2]/a/section/div[2]/div[1]/h2");

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		String descricaoDefaultProduto = dsl.obterTextoObjetoId("product-name-default");

		System.out.println("A descrição do produto clicado na lista foi: " + descricaoDefaultProduto);
		System.out.println("Escolha realizada com sucesso.");

		// System.out.println("Aguardando 5 segundos...");
		// Thread.sleep(5000);

		// System.out.println("Tentativa de compra do primeiro item na lista,
		// pressupondo que não exista em estoque...");
		// dsl.clicarObjetoId("btn-buy");

		System.out.println("Inclusão solicitada e aguardando se há estoque...");

		System.out.println("Aguardando 5 segundos...");
		Thread.sleep(5000);

		Assert.assertEquals("Ops! Já vendemos o estoque", dsl.obterTextoObjetoId("title-stock"));

		System.out.println("Produto procurado fora de estoque e a página respondeu conforme esperado...");
	}

	
	public void buscaProdutoAmericanas(String produto) {
		System.out.println("Iniciando busca...");
		dsl.clicarObjetoId("h_search-input");
		dsl.digitarNoTextbox("h_search-input", produto);
		dsl.clicarObjetoId("h_search-btn");
		System.out.println("Conclusão da Busca.");
	}
	
}
